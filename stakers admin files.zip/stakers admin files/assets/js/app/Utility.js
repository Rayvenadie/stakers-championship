﻿

function ModifytList(chkBox, data) {
      
    var lstArray = [];

    if (!(data === "")) {
        lstArray = data.split(",");
    }

    exist = lstArray.includes(chkBox.value);
    if (chkBox.checked) {

        if (!exist) {
            lstArray.push(chkBox.value);
        }

    }
    else {

        if (exist) {
            var index = lstArray.indexOf(chkBox.value);
            if (index > -1) {
                lstArray.splice(index, 1);
            }
        }

    }

    data = lstArray.join(",");

    return data;

}