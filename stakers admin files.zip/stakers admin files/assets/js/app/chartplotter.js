﻿google.charts.load('current', { 'packages': ['corechart'] });
google.charts.load('current', { 'packages': ['line'] });
google.charts.load('current', { 'packages': ['table'] });

google.charts.setOnLoadCallback(drawChart);

function drawChart()
{
    if (chartType === "pie_chart")
    {
        drawPieChart(divName, title, values, false);
    }
    else if (chartType === "pie_chart_3d") {
        drawPieChart(divName, title, values, true);
    }
    else if (chartType === "bar_chart") {
        drawBarChart(divName, title, values, false);
    }
    else if (chartType === "bar_chart_stacked") {
        drawBarChart(divName, title, values, true);
    }
    else if (chartType === "line_chart") {
        drawMaterialLineChart(divName, title, columns, values);
    }
    else if (chartType === "line_chart_curve") {
        drawLineChart(divName, title, values);
    }
    else if (chartType === "area_chart") {
        drawAreaChart(divName, title, hAxisTitle, minvalue, values);
    }
    else if (chartType === "stepped_chart") {
        drawSteppedChart(divName, title, values);
    }
    else if (chartType === "table") {
        drawTable(divName, title, values);
    }
   
}

function drawAreaChart(divName,title,hAxisTitle,minvalue,values)
{
    var data = google.visualization.arrayToDataTable(values);

    var options = {
        title: title,
        hAxis: { title: hAxisTitle, titleTextStyle: { color: '#333' } },
        vAxis: { minValue: minvalue }
    };

    var chart = new google.visualization.AreaChart(document.getElementById(divName));
    chart.draw(data, options);
}

function drawBarChart(divName,title,values,isstacked)
{
    var data = google.visualization.arrayToDataTable(values);
    var options = {
        title: title,
        isStacked: isstacked
    };

    var chart = new google.visualization.BarChart(document.getElementById(divName));
    chart.draw(data, options);
}

function drawPieChart(divName, title, values,is3d)
{
    var data = google.visualization.arrayToDataTable(values);
    var options = {
        title: title,
        is3D: is3d
    };

    var chart = new google.visualization.PieChart(document.getElementById(divName));
    chart.draw(data, options);
}

function drawLineChart(divName, title, values) {
    var data = google.visualization.arrayToDataTable(values);
    var options = {
        title: title,
        curveType: 'function'
    };

    var chart = new google.visualization.LineChart(document.getElementById(divName));
    chart.draw(data, options);
}

function drawMaterialLineChart(divName, title,columns, values) {
    var data = new google.visualization.DataTable();
    
    columns.forEach(function (c) {
        data.addColumn(c.Value, c.Name);
    });

    data.addRows(values);

    var options = {
        title: title
         };

    var chart = new google.visualization.LineChart(document.getElementById(divName));
    chart.draw(data, options);
}

function drawSteppedChart(divName, title, values) {

    var data = google.visualization.arrayToDataTable(values);
    var options = {
        title: title
    };

    var chart = new google.visualization.SteppedAreaChart(document.getElementById(divName));
    chart.draw(data, options);
}

function drawTable(divName, title, values) {

    var data = new google.visualization.DataTable();

    columns.forEach(function (c) {
        data.addColumn(c.Value, c.Name);
    });

    data.addRows(values);
    
    var table = new google.visualization.Table(document.getElementById(divName));
    table.draw(data, { showRowNumber: true, width: '100%', height: '100%' });

}

